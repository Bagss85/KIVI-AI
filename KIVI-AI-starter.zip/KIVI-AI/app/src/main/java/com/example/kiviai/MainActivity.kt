package com.example.kiviai

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val background = Color.rgb(12, 18, 32)
        val white = Color.WHITE
        val blue = Color.rgb(66, 133, 244)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 32, 48, 32)
            setBackgroundColor(background)
        }

        val title = TextView(this).apply {
            text = "KIVI AI"
            textSize = 38f
            setTextColor(white)
            gravity = Gravity.CENTER
        }

        val subtitle = TextView(this).apply {
            text = "Голосовой помощник для телевизора"
            textSize = 20f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }

        val micButton = Button(this).apply {
            text = "🎙  Начать разговор"
            textSize = 22f
            isFocusable = true
            isFocusableInTouchMode = true
            setOnClickListener {
                status.text = "Микрофон и подключение ИИ будут добавлены на следующем этапе."
                Toast.makeText(
                    this@MainActivity,
                    "Это тестовая версия KIVI AI",
                    Toast.LENGTH_SHORT
                ).show()
            }
            setOnFocusChangeListener { view, hasFocus ->
                view.alpha = if (hasFocus) 1.0f else 0.85f
                view.scaleX = if (hasFocus) 1.04f else 1.0f
                view.scaleY = if (hasFocus) 1.04f else 1.0f
            }
        }

        status = TextView(this).apply {
            text = "Готов к настройке"
            textSize = 17f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }

        val footer = TextView(this).apply {
            text = "Версия 0.1 • Первый экран"
            textSize = 14f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
        }

        layout.addView(title, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 18 })
        layout.addView(subtitle, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 42 })
        layout.addView(micButton, LinearLayout.LayoutParams(420, 76).apply { bottomMargin = 28 })
        layout.addView(status, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 42 })
        layout.addView(footer, LinearLayout.LayoutParams(-1, -2))

        setContentView(layout)
        micButton.requestFocus()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        // Пока оставляем стандартную обработку кнопок пульта.
        return super.onKeyDown(keyCode, event)
    }
}
